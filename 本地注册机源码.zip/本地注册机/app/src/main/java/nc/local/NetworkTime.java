package nc.local;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class NetworkTime {
    private Context context;
	private String TimeUrl="修改网络时间";
	private SharedPreferences sp;
    public NetworkTime(Context context) {
        this.context = context;
    }

    public void getNetworkTime() {
        new NetworkTimeTask().execute();
    }

    private class NetworkTimeTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            String response = "";

            try {
                URL url = new URL(TimeUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                StringBuilder sb = new StringBuilder();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();

                response = sb.toString();
            } catch (Exception e) {
                Log.e("NetworkTimeTask", "Error: " + e.getMessage());
            }

            return response;
        }

        @Override
        protected void onPostExecute(String response) {
			sp =context.getSharedPreferences("bwnc", 0);
            try {
                // 解析 JSON 响应，提取时间字段
                JSONObject json = new JSONObject(response);
                String datetime = json.optString("念程");
				sp.edit().putString("qq",datetime).commit();
				
            } catch (Exception e) {
				sp.edit().putString("qq",machine.dateToStamp(System.currentTimeMillis())).commit();
                Log.e("NetworkTimeTask", "Error: " + e.getMessage());
            }
        }
    }
}

