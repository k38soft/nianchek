package nc.local;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class machine {

    private static final String ALGORITHM = "DES";
    public static SharedPreferences sp ;

    public static void bwnc(final Context context,final String mykey) {
        new NetworkTime(context).getNetworkTime();
        sp = context.getSharedPreferences("bwnc", 0);
        if(!isNcSoExist(context)){
            String a="";
            a.length();
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(0);
        }
        try {
			InputStream inputStream = context.getAssets().open("nc.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            String json = new String(buffer, StandardCharsets.UTF_8);
         
            JSONObject jsonObject = new JSONObject(json);

            // 获取标题数组，并获取其中的元素
            JSONArray titleArray = jsonObject.getJSONArray("标题");
            final String title = titleArray.getString(0);
            final String titleColor = titleArray.getString(1);
            String titleSize = titleArray.getString(2);
            int titleInt = titleArray.getInt(3);
         
            // 获取内容数组，并获取其中的元素
            JSONArray contentArray = jsonObject.getJSONArray("内容");
            String mcontent = contentArray.getString(0);
            String contentColor = contentArray.getString(1);
            final String contentSize = contentArray.getString(2);
            int contentInt = contentArray.getInt(3);
         
            // 获取按钮-1数组，并获取其中的元素
            JSONArray button1Array = jsonObject.getJSONArray("按钮-1");
            String button1Text = button1Array.getString(0);
            final String button1BgColor = button1Array.getString(1);
            final String button1TextColor = button1Array.getString(2);
            final int buttonInt = button1Array.getInt(3);
           
            // 获取按钮-2数组，并获取其中的元素
            JSONArray button2Array = jsonObject.getJSONArray("按钮-2");
            final String button2Text = button2Array.getString(0);
            final String button2Id = button2Array.getString(1);
            final int secretInt = button2Array.getInt(3);
          


            long gettime=sp.getLong("tm", -1);
            Long ncyyds=sp.getLong("ncyyds", -1);
            String qq=sp.getString("qq", "2023-08-09 22:43:59");

            if (gettime != -1 && gettime > TimetoTimestamp(qq) && ncyyds == ((userID(context) + 2023)  - 824) * 4 / 2) {
                tip(context, title, secretInt, button1BgColor, button1TextColor, button1BgColor, titleColor,buttonInt);
                return;
            }

            // 创建对话框构建器
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(CustomizeText(title, titleColor, titleInt));

            SpannableString spannablenews = CustomizeText(new StringBuffer().append(mcontent).append("\n您的设备ID是:"+userID(context)).toString(), contentColor, contentInt);
            builder.setMessage(spannablenews);


            LinearLayout.LayoutParams linearLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );

            int margin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10, 
                                                         context.getResources().getDisplayMetrics());

            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setLayoutParams(linearLayoutParams);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setGravity(Gravity.CENTER_VERTICAL);
            linearLayout.setPadding(margin, 0, margin, 0); 
            final CustomEditText customEditText = new CustomEditText(context);


            //final EditText editText = new EditText(context);
            customEditText.setHint("请输入或者粘贴激活码");
            customEditText.setHintTextColor(Color.parseColor(contentColor));
            customEditText.setTextColor(Color.parseColor(titleColor));
            float cornerRadius = 30f; 

            float[] radii = new float[]{
                cornerRadius, cornerRadius, 
                cornerRadius, cornerRadius, 
                cornerRadius, cornerRadius, 
                cornerRadius, cornerRadius  
            };

            RoundRectShape roundRectShape = new RoundRectShape(radii, null, null);

            ShapeDrawable shapeDrawable = new ShapeDrawable(roundRectShape);
            shapeDrawable.getPaint().setStrokeWidth(3f); // 设置边框宽度
            shapeDrawable.getPaint().setColor(Color.BLUE); // 设置线性布局的背景颜色
            shapeDrawable.getPaint().setStyle(Paint.Style.STROKE); // 设置边框样式
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            );
            int marginValue = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 10, context.getResources().getDisplayMetrics()
            );
            params.setMarginStart(marginValue);
            params.setMarginEnd(marginValue);
            customEditText.setLayoutParams(params);
            linearLayout.addView(customEditText);
            builder.setView(linearLayout);


            // 设置积极按钮（确定按钮）
            builder.setPositiveButton("激活软件", null);
            // 设置负面按钮（取消按钮）
            builder.setNegativeButton("复制ID", null);
            // 设置中性按钮
            builder.setNeutralButton(button1Text, null);
            // 创建对话框并设置为外部不可取消
            final AlertDialog alertDialog = builder.create();
            alertDialog.setCanceledOnTouchOutside(false);
            alertDialog.setCancelable(false);
            // 显示对话框
            alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialog) {
                        try {
                            Resources resources = alertDialog.getContext().getResources();
                            int cornerRadius = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 15, resources.getDisplayMetrics());

                            Window window = alertDialog.getWindow();
                            if (window != null) {
                                Drawable backgroundDrawable = new ColorDrawable(Color.TRANSPARENT);
                                Drawable foregroundDrawable = new GradientDrawable();
                                ((GradientDrawable) foregroundDrawable).setColor(Color.WHITE);
                                ((GradientDrawable) foregroundDrawable).setCornerRadii(new float[]{
                                                                                           cornerRadius, cornerRadius, cornerRadius, cornerRadius,
                                                                                           cornerRadius, cornerRadius, cornerRadius, cornerRadius
                                                                                       });
                                LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{backgroundDrawable, foregroundDrawable});
                                window.setBackgroundDrawable(layerDrawable);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            // build the error message string
                            String errorMessage = "发生异常：" + e.getMessage();
                            // create an AlertDialog.Builder
                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setTitle("错误提示")
                                .setMessage(errorMessage)
                                .setPositiveButton("关闭", null);
                            AlertDialog dialogbug = builder.create();
                            dialogbug.show();
                        }
                        
                        
                    }
                });


            alertDialog.show();

            // 获取按钮实例，并设置点击事件处理
            Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
            init(positiveButton, 30f, button1BgColor, buttonInt + 10, button1TextColor);

            positiveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            String key = decrypt(customEditText.getText().toString(), mykey);
                            long last13Digits =Long.parseLong(key.substring(key.length() - 13));
                            Long digitsBeforeLast13 = Long.parseLong(key.substring(0, key.length() - 13));

                            if (digitsBeforeLast13 == ((userID(context) + 2023) - 824) * 4 / 2) { 
                                if (last13Digits > TimetoTimestamp(sp.getString("qq", ""))) {
                                    Toast.makeText(context, "激活成功!!", Toast.LENGTH_SHORT).show();
                                    sp.edit().putLong("ncyyds", digitsBeforeLast13).putLong("tm", last13Digits).commit();
                                    alertDialog.dismiss();
                                    tip(context, title, secretInt, button1BgColor, button1TextColor, button1BgColor, titleColor,buttonInt);
                                    return;
                                }
                                Toast.makeText(context, "卡密已过期", Toast.LENGTH_LONG).show();
                                return;
                            }
                            Toast.makeText(context, "激活码无效", Toast.LENGTH_LONG).show();
                            return;

                        } catch (Exception e) {
                            Toast.makeText(context, "激活码格式错误❌", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

            Button negativeButton = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
            init(negativeButton, 30f, button1BgColor, buttonInt + 10, button1TextColor);
            negativeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 处理取消按钮点击事件
                        ClipboardManager cm = (ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
                        // 将文本内容放到系统剪贴板里。
                        cm.setText(userID(context) + "");
                        Toast.makeText(context, "ID已复制", Toast.LENGTH_SHORT).show();
                    }
                });
            negativeButton.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    // 从剪贴板获取最新内容，并将其设置到编辑框中
                                    ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                                    if (clipboard != null && clipboard.hasPrimaryClip()) {
                                        ClipData clipData = clipboard.getPrimaryClip();
                                        if (clipData != null && clipData.getItemCount() > 0) {
                                            CharSequence text = clipData.getItemAt(0).coerceToText(context);
                                            if (text != null) {
                                                customEditText.setText(text);
                                                // 将光标移动到文本末尾
                                                customEditText.setSelection(text.length());
                                            }
                                        }
                                    }
                                }
                            });
                        return false;
                    }
                });
            Button neutralButton = alertDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
            init(neutralButton, 30f, button1BgColor, buttonInt + 10, button1TextColor);
            neutralButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (button2Text.equals("跳转QQ号")) {
                            Uri uri = Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=" + button2Id);
                            try {
                                // 创建 Intent
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                // 设置 Intent 的标志位
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                // 启动 Intent
                                context.startActivity(intent);
                            } catch (ActivityNotFoundException e) {
                                // 处理异常：未安装 QQ 客户端的情况，或者没有适合的 Activity 响应该 Intent
                                Toast.makeText(context, "无法启动 QQ，请确保已安装 QQ 客户端", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (button2Text.equals("跳转QQ群")) {

                            try {
                                context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" + button2Id + "&card_type=group&source=qrcode")));

                            } catch (ActivityNotFoundException e) {
                                // 如果无法跳转到QQ群，则打开QQ客户端
                                Intent openQQGroup = new Intent(Intent.ACTION_VIEW);
                                openQQGroup.setData(Uri.parse("https://qm.qq.com/cgi-bin/qm/qr?k=ryoLwhKE87_VmTEfiO8xN4iIHdT3jVwz"));
                                context.startActivity(openQQGroup);
                                // 如果未安装QQ或版本不支持，则捕获ActivityNotFoundException异常
                                Toast.makeText(context, "无法跳转到QQ群，请确保已安装QQ并且版本支持", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (button2Text.equals("跳转浏览器")) {
                            Uri webpage = Uri.parse(button2Id);
                            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

                            if (intent.resolveActivity(context.getPackageManager()) != null) {
                                context.startActivity(intent);
                            } else {
                                // 如果设备上没有安装浏览器应用或无法处理该Intent，则提示用户打开浏览器
                                Toast.makeText(context, "无法打开浏览器，请确保已安装浏览器应用", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            final String errorMessage = "发生异常：" + e.getMessage() + "\n\n" + sw.toString();
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("错误提示")
                .setMessage(errorMessage)
                .setPositiveButton("关闭", null)
                .setNeutralButton("复制", new DialogInterface.OnClickListener(){

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                        clipboard.setText(errorMessage);
                    }
                    
                });
            AlertDialog dialogbug = builder.create();
            dialogbug.show();
            
        }

    }

    public static void init(Button view, float cornerRadius, String BackgroundColor, int TextSize, String TextColor) {
        LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            100 
        );
        buttonLayoutParams.setMargins(20, 0, 10, 0); 
        GradientDrawable buttonBackground = new GradientDrawable();
        buttonBackground.setColor(Color.parseColor(BackgroundColor));
        buttonBackground.setCornerRadii(new float[]{
                                            cornerRadius, cornerRadius, 
                                            cornerRadius, cornerRadius, 
                                            cornerRadius, cornerRadius,
                                            cornerRadius, cornerRadius 
                                        });
        view.setBackground(buttonBackground);
        view.setTextSize(TextSize);
        view.setPadding(10, 5, 10, 5);
        view.setTextColor(Color.parseColor(TextColor));     
        view.setBackground(buttonBackground);
        view.setLayoutParams(buttonLayoutParams);

    }
    private static final int SPAN_EXCLUSIVE_EXCLUSIVE = 0;
    public static SpannableString CustomizeText(String input, String textColor, float textSize) {
        SpannableString spannableString = new SpannableString(input);
        // 设置文本颜色
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.parseColor(textColor));
        spannableString.setSpan(colorSpan, 0, input.length(), 0);
        // 设置字体大小
        RelativeSizeSpan sizeSpan = new RelativeSizeSpan(textSize / 5);
        spannableString.setSpan(sizeSpan, 0, input.length(), 0);
        return spannableString;
    }
    public static SpannableString CustomizeText1(String input, String textColor, int textSize) {
        SpannableString spannableString = new SpannableString(input);
        // 设置文本颜色
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.parseColor(textColor));
        spannableString.setSpan(colorSpan, 0, input.length(), 0);
        // 设置字体大小
        spannableString.setSpan(new AbsoluteSizeSpan(textSize), 0, input.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        return spannableString;
    }

    public static SpannableString formatTextWithRandomColor(String input) {
        SpannableString spannableString = new SpannableString(input);
        // 随机生成颜色
        int length = input.length();
        for (int i = 0; i < length; i++) {
            char c = input.charAt(i);
            int color = getRandomColor();
            // 设置字符颜色
            ForegroundColorSpan span = new ForegroundColorSpan(color);
            spannableString.setSpan(span, i, i + 1, SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return spannableString;
    }

    public static SpannableString CustomizeTextColor(String input, String TextColor) {
        SpannableString spannableString = new SpannableString(input);
        ForegroundColorSpan span = new ForegroundColorSpan(Color.parseColor(TextColor));
        spannableString.setSpan(span, 0, input.length(), 0);
        return spannableString;
    }
    private static int getRandomColor() {
        return Color.rgb((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256));
    }

    public static Long TimetoTimestamp(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            Date date = sdf.parse(dateString);
            long timestamp = date.getTime();
            return timestamp;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }
    public static String dateToStamp(Long timestamp) { 
        Date date = new Date(timestamp);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = sdf.format(date);

        return formattedDate; 
    }
    public static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0;i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }
    public static String decrypt(String encryptedValue, String key) {
        try {
            DESKeySpec desKeySpec = new DESKeySpec(key.getBytes(StandardCharsets.UTF_8));
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM);
            SecretKey secretKey = keyFactory.generateSecret(desKeySpec);

            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new SecureRandom());
            return new String(cipher.doFinal(parseHexStr2Byte(encryptedValue)));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String loveid(Context Context) {
        String loveid = Settings.System.getString(Context.getContentResolver(), Settings.Secure.ANDROID_ID)+Context.getPackageName();
        return loveid;
    }
    public static long userID(Context nc) {
        int hashCode = loveid(nc).hashCode();
        int fiveDigitNumber = Math.abs(hashCode) % 100000000;
        long formattedNumber = Long.parseLong(String.format("%07d", fiveDigitNumber));
        return formattedNumber;
    }
    public static boolean isNcSoExist(Context context) {
        try {
            AssetManager assetManager = context.getAssets();
            String[] files = assetManager.list("");
            if (files != null) {
                for (String fileName : files) {
                    if (fileName.equals("nc.json")) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void tip(Context nc, String title, final int clickCount, String bgcolor, String txtcolor, String newscolor, String titlecolor,int contextsize) {
        AlertDialog.Builder builder = new AlertDialog.Builder(nc);
        String qq=sp.getString("qq", "2023-08-09 22:43:59");
        long gettime=sp.getLong("tm", -1);

        // 设置对话框标题和消息内容
        SpannableString spannableTitle = new SpannableString(title);
        spannableTitle.setSpan(new ForegroundColorSpan(Color.parseColor(titlecolor)), 0, title.length(), 0);
        builder.setTitle(spannableTitle);

        SpannableString spannablenews = new SpannableString(new StringBuffer().append(new StringBuffer()
                                                                                      .append("恭喜您！已成功激活软件")
                                                                                      .append("\n当前时间:" + qq)
                                                                                      .append("\n将于:" + dateToStamp(gettime)) + "到期"));
        spannablenews.setSpan(new ForegroundColorSpan(Color.parseColor(newscolor)), 0, qq.length() + dateToStamp(gettime).length() + 23, 0);
        builder.setMessage(spannablenews);


        if (sp.getInt("clickCount", 0) == clickCount) {
            return;
        }

        builder.setPositiveButton("朕已查阅", null);
        final AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    try {
                        Resources resources = alertDialog.getContext().getResources();
                        int cornerRadius = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 15, resources.getDisplayMetrics());

                        Window window = alertDialog.getWindow();
                        if (window != null) {
                            Drawable backgroundDrawable = new ColorDrawable(Color.TRANSPARENT);
                            Drawable foregroundDrawable = new GradientDrawable();
                            ((GradientDrawable) foregroundDrawable).setColor(Color.WHITE);
                            ((GradientDrawable) foregroundDrawable).setCornerRadii(new float[]{
                                                                                       cornerRadius, cornerRadius, cornerRadius, cornerRadius,
                                                                                       cornerRadius, cornerRadius, cornerRadius, cornerRadius
                                                                                   });
                            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{backgroundDrawable, foregroundDrawable});
                            window.setBackgroundDrawable(layerDrawable);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

        alertDialog.show();

        final Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        LinearLayout.LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            100 // 将35dp转换为像素值
        );
        positiveButton.setTextSize(10+contextsize);
        positiveButton.setPadding(10, 5, 10, 5);
        positiveButton.setTextColor(Color.parseColor(txtcolor));

        float cornerRadius = 30f; // 设置按钮四个角的圆角半径

        GradientDrawable buttonBackground = new GradientDrawable();
        buttonBackground.setColor(Color.parseColor(bgcolor)); // 设置按钮的背景颜色
        buttonBackground.setCornerRadii(new float[]{
                                            cornerRadius, cornerRadius, 
                                            cornerRadius, cornerRadius, 
                                            cornerRadius, cornerRadius, 
                                            cornerRadius, cornerRadius  
                                        });
        positiveButton.setBackground(buttonBackground);

        positiveButton.setLayoutParams(buttonLayoutParams);
        positiveButton.setOnClickListener(new View.OnClickListener() {
                int Count = sp.getInt("clickCount", 0); 

                @Override
                public void onClick(View v) {
                    if (Count < clickCount) {
                        Count++;
                        sp.edit().putInt("clickCount", Count).commit();
                        alertDialog.dismiss();

                    }
                }
            });

    }


}

