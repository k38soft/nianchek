package nc.local;

/**
 * @作者 不忘念程
 * @日期 2023/09/15 05:34
 * @描述 交流群:307154799
 */
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.EditText;

public class CustomEditText extends EditText {

    private Paint borderPaint;
    private Path borderPath;
    private RectF borderRect;
    private int cornerRadius = 30;

	private int leftMargin=10;

	private int topMargin;

	private int rightMargin=20;

	private int bottomMargin;

    public CustomEditText(Context context) {
        super(context);

        init();
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

	public void setMargins(int left, int top, int right, int bottom) {
        leftMargin = left;
        topMargin = top;
        rightMargin = right;
        bottomMargin = bottom;
        invalidate(); 
    }
    private void init() {
        borderPaint = new Paint();
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(Color.BLUE);
        borderPaint.setStrokeWidth(4);

        borderPath = new Path();
        borderRect = new RectF();
		setBackground(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        borderPath.reset();
        borderRect.set(2, 2, getWidth() - 2, getHeight() - 2);
        borderPath.addRoundRect(borderRect, cornerRadius, cornerRadius, Path.Direction.CW);
        canvas.drawPath(borderPath, borderPaint);

        super.onDraw(canvas);
    }
}
